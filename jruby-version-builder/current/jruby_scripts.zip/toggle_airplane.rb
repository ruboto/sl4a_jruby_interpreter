# Toggle airplane mode twice to fix stuck GPS/networks...
droid = Android.new
droid.toggleAirplaneMode
droid.toggleAirplaneMode

